import React, { useState, useEffect } from 'react';

function MoodSelector() {
  const [moods, setMoods] = useState([]);
  const [selectedMood, setSelectedMood] = useState(null);

  useEffect(() => {
    fetch("../../moods.json")
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch mood data');
        }
        return response.json();
      })
      .then(data => setMoods(data.moods))
      .catch(error => console.error('Error fetching mood data:', error));
  }, []);
  

  const handleMoodSelect = (mood: any) => {
    setSelectedMood(mood);
  };

  const selectedMoodData = moods.find(mood => mood.name === selectedMood);
  const playlistId = selectedMoodData ? selectedMoodData.playlistId : null;

  return (
    <div className="screen-container">
      <h2>Select your mood:</h2>
      <ul>
        {moods.map(mood => (
          <li key={mood.name} onClick={() => handleMoodSelect(mood)}>{mood.name}</li>
        ))}
      </ul>
      {playlistId && (
        <iframe src={`https://open.spotify.com/embed/playlist/${playlistId}`} width="300" height="380" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>
      )}
    </div>
  );
}

export default MoodSelector;
