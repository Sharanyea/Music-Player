import React from "react";
import Home from "./screens/home/home";

export default function App(){
  return(
    <div>
      <Home />
    </div>
  );
}